#include "Game.h"
#include <iostream>

int main()
{
    Game game(1280, 720);
    game.start();
}