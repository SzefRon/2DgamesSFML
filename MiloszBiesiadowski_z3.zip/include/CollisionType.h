#pragma once

enum CollisionType
{
    CIRCLE,
    SQUARE
};